export class PortTable {
    port_code: string
    port_id: string
    port_city_id: string
    port_city_name: string
    port_country_id: string
    port_country_name: string
    port_name: string
    port_region: string
    port_disable: number
}
