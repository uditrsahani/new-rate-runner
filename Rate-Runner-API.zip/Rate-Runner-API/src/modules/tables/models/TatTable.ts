export class TatTable {
    lt_id: number
    lt_timestamp: string
    lt_waiting_sales: number
    lt_waiting_mktg: number
    lt_waiting_cus: number
    lt_waiting_quotation: number
}
