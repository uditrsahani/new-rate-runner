export class RateTableConflict {
    rate_input_no: string
    duplicate: boolean = false
    agent_found: boolean = false
    cr_found: boolean = false
    pol_found: boolean = false
    pod_found: boolean = false
    cus_found: boolean = false
}
