export class AgentProfile {
    agent_id: string
    agent_code: string
    agent_city_id: string
    agent_city_name: string
    agent_country_id: string
    agent_country_name: string
    agent_name: string
    agent_address: string
    agent_type: string
    agent_other: string
    agent_mobile: string
    agent_phone: string
    agemt_mail: string
    agent_official_social_id: string
    agent_website: string
    agent_remark: string
    agent_disable: number
}
