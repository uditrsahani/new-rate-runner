export class CustomerProfileQueryParam {
    cus_id: string[]
    cus_name: string
}
