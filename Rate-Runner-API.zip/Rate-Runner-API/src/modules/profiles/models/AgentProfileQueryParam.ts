export class AgentProfileQueryParam {
    agent_id: string
}
