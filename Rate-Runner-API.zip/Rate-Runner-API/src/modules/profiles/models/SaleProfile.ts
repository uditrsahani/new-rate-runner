import { UserAccount } from "app/modules/auth/models/UserAccount";

export class SaleProfileModel extends UserAccount {

}
