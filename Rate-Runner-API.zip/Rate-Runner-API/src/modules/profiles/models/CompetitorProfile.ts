export class Competitor {
    ct_id: string
    ct_city_id: string
    competitor_city_name: string
    competitor_country_name: string
    ct_country_id: string
    ct_name: string
    ct_code: string
    ct_address: string
    ct_mobile: string
    ct_phone: string
    ct_mail: string
    ct_official_social_id: string
    ct_website: string
    ct_remark: string
    ct_disable: number
}
