import { Token } from "typedi";

export interface IRateTableRepository {

}

const RateTableRepositoryToken = new Token<IRateTableRepository>();
