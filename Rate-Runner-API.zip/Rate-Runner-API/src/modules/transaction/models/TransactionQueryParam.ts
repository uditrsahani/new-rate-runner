export class TransactionQueryParam {
    inq_uuid: string[]
}
