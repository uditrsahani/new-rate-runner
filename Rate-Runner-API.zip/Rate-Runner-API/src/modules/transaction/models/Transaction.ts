export class Transaction {
    tx_uuid: string
    tx_time: string
    tx_target_uuid: string
    tx_target_status: string
    tx_target_type: string
    tx_owner: string
    tx_comment: string
}
