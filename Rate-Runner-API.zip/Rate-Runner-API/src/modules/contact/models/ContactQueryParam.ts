export class ContactQueryParam {
    ct_uuid: string
    ct_refer_id: string
    ct_refer_table: string
}
