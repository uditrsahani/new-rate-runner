export class Contact {
    agent_name: string
    cus_name: string
    cr_name: string
    ct_uuid: string
    ct_refer_table: string
    ct_refer_id: string
    ct_name: string
    ct_position: string
    ct_department: string
    ct_mail: string
    ct_mobile: string
    ct_phone: string
    ct_social_id: string
    ct_type: string
    ct_disable: string
}
