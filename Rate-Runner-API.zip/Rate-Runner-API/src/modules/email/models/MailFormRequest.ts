export class MailFormRequest {
    form: string;
    to: string;
    cc: string;
    subject: string;
    html: string;
}