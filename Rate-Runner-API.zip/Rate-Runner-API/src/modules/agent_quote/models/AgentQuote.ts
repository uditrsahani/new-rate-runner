export class AgentQuote {
    aq_id: string
    aq_agent_id: string
    aq_inq_no: string
    aq_select: string
    aq_currency_cp_shpmt: string
    aq_cp_shpmt: number
    aq_currency_cp_cntr: string
    aq_cp_cntr: number
    aq_currency_dp_shpt: string
    aq_dp_shpt: number
    aq_currency_dp_cntr: string
    aq_dp_cntr: number
    aq_mail: string
    aq_sq_cp_shpmt: string
    aq_sq_cp_cntr: string
    aq_sq_dp_shpt: string
    aq_sq_dp_cntr: string
    aq_filename: string
}
