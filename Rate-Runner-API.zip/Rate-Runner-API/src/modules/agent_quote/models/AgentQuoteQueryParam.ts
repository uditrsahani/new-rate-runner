export class AgentQuoteQueryParam {
    aq_id: string
}
