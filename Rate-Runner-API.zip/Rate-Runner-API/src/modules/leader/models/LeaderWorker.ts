export class LeaderWorker {
    leader_user_id: string
    worker_user_id: string
}
