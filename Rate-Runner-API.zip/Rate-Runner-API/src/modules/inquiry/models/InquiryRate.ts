export class InquiryRate {
    inq_rate_uuid: string
    inq_uuid: string
    rate_id: string
    rate_recommend: string
}
