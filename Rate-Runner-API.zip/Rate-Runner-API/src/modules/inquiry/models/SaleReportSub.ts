export class SaleReportSub {
    cus_type: string
    user_team: string
    count: number
    win: number
    loss: number
    pending: number
    disable: number
}
