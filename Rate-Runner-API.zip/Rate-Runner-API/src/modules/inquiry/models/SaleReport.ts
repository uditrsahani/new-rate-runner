import { SaleReportSub } from "./SaleReportSub";

export class SaleReport {
    head: SaleReportSub
    current: SaleReportSub
    key: SaleReportSub
    new: SaleReportSub
}
