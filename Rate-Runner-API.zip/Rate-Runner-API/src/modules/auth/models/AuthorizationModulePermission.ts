export enum AuthorizationModulePermission {
    sales = "sales",
    marketing = "marketing",
    salesManager = "salesManager",
    management = "management",
    marketingManager = "marketingManager",
    systemAdmin = "systemAdmin"
}