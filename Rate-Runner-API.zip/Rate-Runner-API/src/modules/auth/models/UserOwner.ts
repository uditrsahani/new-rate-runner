export class UserOwner {
    user_id: string
    user_team: string
    user_role: string
    cus_id: string
}
