export class UserAccountQueryParam {
    user_id: string
    user_ids: string[]
    user_mail: string
    user_role: string
    user_roles: string[]
    user_team: string
}
