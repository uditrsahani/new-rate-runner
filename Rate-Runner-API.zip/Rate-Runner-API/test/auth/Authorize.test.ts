import { suite, test } from '@testdeck/mocha';
import * as assert from 'assert';

@suite("Authorize Test")
class AuthorizeTest {

    @test("Login Test")
    login() {

        assert.ok(true);
    }
}